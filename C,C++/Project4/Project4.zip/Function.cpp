/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Function.cpp
 * Author: eriko
 * 
 * Created on November 14, 2017, 1:10 PM
 */

#include "Function.h"

