/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Value.cpp
 * Author: eriko
 * 
 * Created on November 1, 2017, 12:54 PM
 */

#include <string>
#include "Value.h"


using namespace std;

//virtual string Value::getValue()=0;
//virtual bool Value::equal(string val)=0;


