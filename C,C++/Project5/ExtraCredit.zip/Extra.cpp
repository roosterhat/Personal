/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Extra.cpp
 * Author: erik ostlind
 * jeo170030
 * Created on November 26, 2017, 9:38 PM
 */

#include "Grid.h"
#include "Node.h"
#include <iostream>

int main() {
    Grid* grid = new Grid(50,50);
    cout<<"Rows: "<<grid->getRows()<<endl<<"Columns: "<<grid->getColumns()<<endl; 
    for(int y=0;y<50;y++)
        for(int x=0;x<50;x++){
            Node* n = grid->get(x,y)->getValue();
            cout<<n->toString()<<endl;
        }
    return 0;
}
