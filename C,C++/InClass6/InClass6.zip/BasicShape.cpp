/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   BasicShape.cpp
 * Author: erik ostlind
 * jeo170030
 * Kevin Salinda
 * kms170630
 * Created on December 5, 2017, 1:15 PM
 */

#include "BasicShape.h"

double BasicShape::getArea(){
    return area;
}

double BasicShape::getPerimeter(){
    return perimeter;
}

string BasicShape::getName(){
    return name;
}


