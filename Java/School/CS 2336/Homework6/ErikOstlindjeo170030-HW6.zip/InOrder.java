/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework6;

/**
 *
 * @author eriko
 */
public class InOrder extends Arrangment{
    public InOrder(){
        super("InOrder");
    }
    public Integer[] rearrangeList(Integer[] list){
        return list;
    }
}
