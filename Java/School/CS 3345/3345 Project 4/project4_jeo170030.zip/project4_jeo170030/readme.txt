Erik Ostlind
jeo170030
NetBeans

===Zip Contents===
./project4_jeo170030/
main = 	> project4.java: takes two command line arguments (source file, destination file). !!Must be absolute file paths!! 
	> RedBlackTree.java: red black tree implementation
	../CommandInterpreter/
		> Command.java: command object, used by CommandInterpreter.java
		> CommandInterpreter.java: interprets commands and executes their functions
		> Function.java: interface used by Command.java