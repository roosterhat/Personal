Erik Ostlind
JEO170030
Project 3
IDE: NetBeans

-Files-
* Projec3.java
* LazyBinarySearchTree.java
* CommandInterpreter.CommandInterpreter.java
* CommandInterpreter.Command.java
* CommandInterpreter.Function.java

Takes 2 command line arguments '<Source file> <destination file>'