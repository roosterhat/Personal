(seconds)		|100	|1000	|5000	|10000 	|50000
_______________________________________________________________
First 			|0.002	|0.007	|0.002	|0.003	|0.013
Random			|0.0008	|0.006	|0.002	|0.003	|0.017
Random Median		|0.002	|0.014	|0.015	|0.011	|0.026
First, Mid, Last Median	|0.0006	|0.002	|0.007	|0.015	|0.017	

Random Median seems to be the worst of the pivots, the overall time doesnt increase very much from 100 to 10000
